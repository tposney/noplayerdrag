cd ..
zip -r noplayerdrag.zip noplayerdrag -x \*.git/* -x noplayerdrag/noplayerdrag.zip

