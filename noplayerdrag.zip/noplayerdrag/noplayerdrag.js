function myCanDrag(wrapped, ...args) {
    const canDrag = wrapped(...args);
    if (!game.user.isGM) return false;
    return canDrag;
}

Hooks.once('ready', function () {
	if (game.modules.get("lib-wrapper")?.active) {
	    libWrapper.register("noplayerdrag", "Token.prototype._canDrag", myCanDrag, "WRAPPER");
	} else {
		console.error("Libwrapper must be instaalled and active");
	}
});
